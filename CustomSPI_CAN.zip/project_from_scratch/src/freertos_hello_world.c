/*
    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Copyright (c) 2012 - 2020 Xilinx, Inc. All Rights Reserved.
	SPDX-License-Identifier: MIT


    http://www.FreeRTOS.org
    http://aws.amazon.com/freertos


    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "xuartps.h"			//questa serve per le funzioni di inizializzazione, trasmissione e ricezione verso la UART (verso l'host).
#include "platform.h"			//questa serve per le funzioni init_platform() e cleanup_platform().
//#include "SPI.h"

#include "Devicelib.h"

#define TIMER_ID	1
#define DELAY_30_SECONDS	30000UL
#define DELAY_10_SECONDS	10000UL
#define DELAY_2_SECONDS		2000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9
/*---------------------------------------------------------------------------*/

/* The Tx and Rx tasks as described at the top of this file. */
static void talkWithSPI_CAN_Task( void *pvParameters );
static void talkWithHostTask( void *pvParameters );
static void TaskStampa( void *pvParameters );

void MY_RX_canframe(volatile unsigned int * SPI_Controller, struct QueueDefinition * xQueue);

/*---------------------------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */
static TaskHandle_t xTxTask;
static TaskHandle_t xRxTask;
static TaskHandle_t xTaskStampa;
static QueueHandle_t xQueue = NULL;
char HWstring[32] = "Hello World";
XUartPs_Config *Config_1;
XUartPs Uart_PS_1;
volatile unsigned int * SPI_Controller = (volatile unsigned int *) 0x43c00000;
struct BufferQueue * Msg_Queue;




int main( void )
{


	//COPIA CODICE DOTTORANDO
	init_platform();
	int Status;
	Config_1 = XUartPs_LookupConfig(XPAR_PS7_UART_1_DEVICE_ID);	//questa prima funzione inizializza questa struttura a puntare alla UART1,
	if (Config_1 == NULL) {	//che ha le seguenti caratteristiche (prestabilite, non modificabili, credo):
		return XST_FAILURE;			//XPAR_PS7_UART_1_DEVICE_ID			=	0
	}						//XPAR_PS7_UART_1_BASEADDR			=	0xE0001000
	Status = XUartPs_CfgInitialize(&Uart_PS_1, Config_1, Config_1->BaseAddress);//XPAR_PS7_UART_1_UART_CLK_FREQ_HZ	=	100.000.000
	if (Status != XST_SUCCESS) {	//XPAR_PS7_UART_1_HAS_MODEM			=	NO
		return XST_FAILURE;
	}//invece la seconda funzione, tra le altre cose, setta il baudrate (questa
	Status= XUartPs_SelfTest(&Uart_PS_1);
	if (Status != XST_SUCCESS) {
	   return XST_FAILURE;
	}
	Boot(SPI_Controller);
	init_queue(&Msg_Queue);

	//FINE COPIA CODICE DOTTORANDO



	/* Create the two tasks.  The Tx task is given a lower priority than the
	Rx task, so the Rx task will leave the Blocked state and pre-empt the Tx
	task as soon as the Tx task places an item in the queue. */
	xTaskCreate( 	talkWithSPI_CAN_Task, 					/* The function that implements the task. */
					( const char * ) "Tx", 		/* Text name for the task, provided to assist debugging only. */
					configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task. */
					NULL, 						/* The task parameter is not used, so set to NULL. */
					tskIDLE_PRIORITY,			/* The task runs at the idle priority. */
					&xTxTask );

/*	xTaskCreate( talkWithHostTask,
				 ( const char * ) "GB",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY,
				 &xRxTask );
*/
	xTaskCreate( TaskStampa,
				 ( const char * ) "GB2",
				 configMINIMAL_STACK_SIZE,
				 NULL,
				 tskIDLE_PRIORITY,
				 &xTaskStampa );


	/* Create the queue used by the tasks.  The Rx task has a higher priority
	than the Tx task, so will preempt the Tx task and remove values from the
	queue as soon as the Tx task writes to the queue - therefore the queue can
	never have more than one item in it. */
//	xQueue = xQueueCreate( 	1,						/* There is only one space in the queue. */
//							sizeof( HWstring ) );	/* Each space in the queue is large enough to hold a uint32_t. */

	xQueue = xQueueCreate( 	256,						/* There is only one space in the queue. */
							sizeof( struct CANFrame ) );	/* Each space in the queue is large enough to hold a uint32_t. */

	/* Check the queue was created. */
	configASSERT( xQueue );


	xil_printf( "Configurazione iniziale completata...\r\n" );


	/* Start the tasks and timer running. */
	vTaskStartScheduler();

	/* If all is well, the scheduler will now be running, and the following line
	will never be reached.  If the following line does execute, then there was
	insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	to be created.  See the memory management section on the FreeRTOS web site
	for more details. */
	for( ;; );
}





/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/*---------------------------  TASK VERSO ZYBO  -----------------------------*/
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

static void talkWithSPI_CAN_Task( void *pvParameters ) {


	struct CANFrame * frame;
	struct CANFrame * frame2;


	for( ;; ) {


//		RX_canframe(SPI_Controller,Msg_Queue);

//		MY_RX_canframe(SPI_Controller, xQueue);




		SPI_Controller[3] = 0x000000a0; //Require status from PmodCAN
		while((SPI_Controller[5] & 0x03C00000) >> 22 == 0); //Check if there are Received messages on the SPI interface
		SPI_Controller[4];

		if( uxQueueSpacesAvailable(xQueue) ){		//if( (*xQueue)->uxLength != QMAXSIZE ){

			if((SPI_Controller[0] & 0x00000003) == 0x01 || (SPI_Controller[0] & 0x00000003) == 0x03){ //Check if a message is received on the PmodCAN Buffer 0

				RX_message( SPI_Controller, 0, xQueueSend( xQueue, frame, 0UL) );		//xQueue->pcWriteTo

	//			if (Q->frame->Data[0] != 0x01 && Q->frame->Data[3] != 0x04) {

	//				Q->tail = (Q->tail + 1)%(QMAXSIZE);		//QUESTA NON SERVE, PER� BISOGNA IMPLEMENTARE LA CODA CIRCOLARE
	//				Q->size++;								//CONTROLLARE SE LO FA DA SOLO
	//				Q->bytes = get_msg_bytes(Q,Q->size);	//NON SO SE SERVE

	//			}

			}

			else if((SPI_Controller[0] & 0x00000003) == 0x02){ //Check if a message is received on the PmodCAN Buffer 1

				RX_message( SPI_Controller, 1, xQueueSend( xQueue, frame, 0UL) );		//xQueue->pcWriteTo

	//			if (Q->frame->Data[0] != 0x01 && Q->frame->Data[3] != 0x04) {

	//				Q->tail = (Q->tail + 1)%(QMAXSIZE);		//QUESTA NON SERVE, PER� BISOGNA IMPLEMENTARE LA CODA CIRCOLARE
	//				Q->bytes = get_msg_bytes(Q,Q->size);	//NON SO SE SERVE

	//			}
			}
		}

		if( uxQueueMessagesWaiting (xQueue) ){

			xQueueReceive( 	xQueue, frame2, portMAX_DELAY );

			xil_printf( "Coda: %x\r\n", frame2->ID);

		}





		/* Send the next value on the queue.  The queue should always be
		empty at this point so a block time of 0 is used. */
//		xQueueSend( xQueue,			/* The queue being written to. */
//					&frame, /* The address of the data being sent. */
//					0UL );			/* The block time. */
	}
}





/*
void MY_RX_canframe(volatile unsigned int * SPI_Controller, struct QueueDefinition * xQueue){

	struct CANFrame * frame;

	SPI_Controller[3] = 0x000000a0; //Require status from PmodCAN
	while((SPI_Controller[5] & 0x03C00000) >> 22 == 0); //Check if there are Received messages on the SPI interface
	SPI_Controller[4];

	if( uxQueueSpacesAvailable(xQueue) ){		//if( (*xQueue)->uxLength != QMAXSIZE ){

		if((SPI_Controller[0] & 0x00000003) == 0x01 || (SPI_Controller[0] & 0x00000003) == 0x03){ //Check if a message is received on the PmodCAN Buffer 0

			RX_message( SPI_Controller, 0, xQueueSend( xQueue, frame, 0UL) );		//xQueue->pcWriteTo

//			if (Q->frame->Data[0] != 0x01 && Q->frame->Data[3] != 0x04) {

//				Q->tail = (Q->tail + 1)%(QMAXSIZE);		//QUESTA NON SERVE, PER� BISOGNA IMPLEMENTARE LA CODA CIRCOLARE
//				Q->size++;								//CONTROLLARE SE LO FA DA SOLO
//				Q->bytes = get_msg_bytes(Q,Q->size);	//NON SO SE SERVE

//			}

		}

		else if((SPI_Controller[0] & 0x00000003) == 0x02){ //Check if a message is received on the PmodCAN Buffer 1

			RX_message( SPI_Controller, 1, xQueueSend( xQueue, frame, 0UL) );		//xQueue->pcWriteTo

//			if (Q->frame->Data[0] != 0x01 && Q->frame->Data[3] != 0x04) {

//				Q->tail = (Q->tail + 1)%(QMAXSIZE);		//QUESTA NON SERVE, PER� BISOGNA IMPLEMENTARE LA CODA CIRCOLARE
//				Q->bytes = get_msg_bytes(Q,Q->size);	//NON SO SE SERVE

//			}
		}
	}


}
*/





/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/*--------------------------  TASK VERSO HOST  ------------------------------*/
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

static void talkWithHostTask( void *pvParameters ) {

	const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );

	char Recdstring[20] = "";

	struct CANFrame * frame;

	vTaskDelay( x1second );		//ritardo di 1s per far in modo che parta prima l'altro task

	for( ;; ) {

		/* Block to wait for data arriving on the queue. */
		xQueueReceive( 	xQueue,				/* The queue being read. */
						frame,				/* Data is read into this address. */
						portMAX_DELAY );	/* Wait without a timeout for data. */

		/* Print the received data. */
		//xil_printf( "talkWithHostTask received string from talkWithSPI_CAN_Task: %s\r\n", Recdstring );
		XUartPs_Send(&Uart_PS_1, strcat(frame, "\r\n"), sizeof(Recdstring));
	}
}





/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/
/*---------------------------  TASK DI STAMPA  ------------------------------*/
/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

static void TaskStampa( void *pvParameters ) {

	const TickType_t x2seconds = pdMS_TO_TICKS( DELAY_2_SECONDS );

	const TickType_t x30seconds = pdMS_TO_TICKS( DELAY_30_SECONDS );

	vTaskDelay( x2seconds );		//ritardo di 2s per far in modo che partano prima gli altri task

	for( ;; ) {

		xil_printf( "*** TASK DI STAMPA ***\r\n" );
		xil_printf( "MESSAGGI IN ARRIVO DAI SENSORI:\r\n" );

		xil_printf( "ID (del generatore CAN): %x\r\n", Msg_Queue->frame->ID );

		for( int i=0; i<256; i++ ) {

			if (   Msg_Queue->frame[i].Data[7] != 0x08   &&   Msg_Queue->frame[i].Data[6] != 0x07   ) {

				xil_printf( "Campo dati del frame CAN %u: %x ", i, Msg_Queue->frame[i].Data[0] );

				for( int j=1; j<8; j++ ) {

					xil_printf( "%x ", Msg_Queue->frame[i].Data[j] );

				}

				xil_printf( "%x\r\n", Msg_Queue->frame[i].Data[7] );

			}

		}

		vTaskDelay( x30seconds );

	}

}




